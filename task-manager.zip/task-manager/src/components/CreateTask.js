// CreateTask.js

import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './styles.css'; // Import CSS file for styling

function CreateTask() {
    const [Title, setTask] = useState('');
    const [description, setDescription] = useState('');
    const [status, setStatus] = useState('pending');
    const [dueDate, setDueDate] = useState('');
    const navigate = useNavigate();
    


    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
          //  const dueDateUtc = new Date(dueDate).toISOString();
            const newTask = { Title, description, status, dueDate };
            await axios.post('https://localhost:7124/api/Tasks', newTask);
            // Navigate to the task list page after successful task creation
            navigate('/');
        } catch (error) {
            if (error.response) {
                // The request was made and the server responded with a status code
                // that falls out of the range of 2xx
                console.error('Server Error:', error.response.data);
            } else if (error.request) {
                // The request was made but no response was received
                console.error('No Response from Server:', error.request);
            } else {
                // Something happened in setting up the request that triggered an Error
                console.error('Request Error:', error.message);
            }
        }
    };

    return (
        <div className="create-task-container">
            <h1>Create New Task</h1>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Task:</label>
                    <input type="text" value={Title} onChange={(e) => setTask(e.target.value)}  />
                </div>
                <div className="form-group">
                    <label>Description:</label>
                    <textarea value={description} onChange={(e) => setDescription(e.target.value)} />
                </div>
                <div className="form-group">
                    <label>Status:</label>
                    <select value={status} onChange={(e) => setStatus(e.target.value)} required>
                        <option value="pending">Pending</option>
                        <option value="in progress">In Progress</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <div className="form-group">
                    <label>Due Date:</label>
                    <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value.toISOString)} required />
                </div>
                <button type="submit" className="submit-button">Create Task</button>
            </form>
        </div>
    );
}

export default CreateTask;
