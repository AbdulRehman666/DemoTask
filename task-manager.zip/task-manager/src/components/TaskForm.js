import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import './styles.css';

function TaskForm() {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [status, setStatus] = useState('pending');
    const [dueDate, setDueDate] = useState('');
    const navigate = useNavigate();
    const { id } = useParams();

    useEffect(() => {
        if (id) {
            axios.get(`https://localhost:7124/api/Tasks/${id}`)
                .then(response => {
                    setTitle(response.data.title);
                    setDescription(response.data.description);
                    setStatus(response.data.status);
                    setDueDate(response.data.dueDate);
                })
                .catch(error => console.error(error));
        }
    }, [id]);

    const handleSubmit = (e) => {
        e.preventDefault();
        const task = { title, description, status, dueDate };

        if (id) {
            axios.put(`https://localhost:7124/api/Tasks/${id}`, task)
                .then(() => navigate('/'))
                .catch(error => console.error(error));
        } else {
            axios.post('https://localhost:7124/api/Tasks', task)
                .then(() => navigate('/'))
                .catch(error => console.error(error));
        }
    };

    return (
        <div className="container">
            <h1>{id ? 'Edit Task' : 'Create Task'}</h1>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label className="label">Title</label>
                    <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} className="input" required />
                </div>
                <div className="form-group">
                    <label className="label">Description</label>
                    <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} className="input" />
                </div>
                <div className="form-group">
                    <label className="label">Status</label>
                    <select value={status} onChange={(e) => setStatus(e.target.value)} className="select" required>
                        <option value="pending">Pending</option>
                        <option value="in progress">In Progress</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <div className="form-group">
                    <label className="label">Due Date</label>
                    <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="input" />
                </div>
                <button type="submit" className="button">{id ? 'Update' : 'Create'}</button>
            </form>
        </div>
    );
}

export default TaskForm;
