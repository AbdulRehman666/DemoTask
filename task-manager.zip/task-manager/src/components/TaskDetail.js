import React, { useEffect, useState } from 'react';
import axios from 'axios';

function TaskDetail({ match }) {
  const [task, setTask] = useState(null);

  useEffect(() => {
    axios.get(`https://localhost:7124/api/Tasks/${match.params.id}`)
      .then(response => setTask(response.data))
      .catch(error => console.error(error));
  }, [match.params.id]);

  if (!task) return <div>Loading...</div>;

  return (
    <div>
      <h1>{task.title}</h1>
      <p>{task.description}</p>
      <p>Status: {task.status}</p>
      <p>Due Date: {task.dueDate}</p>
    </div>
  );
}

export default TaskDetail;
