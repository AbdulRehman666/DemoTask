import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function TaskList() {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    axios.get('https://localhost:7124/api/Tasks')
      .then(response => setTasks(response.data))
      .catch(error => console.error(error));
  }, []);

  const handleDelete = (id) => {
    axios.delete(`https://localhost:7124/api/Tasks/${id}`)
      .then(() => setTasks(tasks.filter(task => task.id !== id)))
      .catch(error => console.error(error));
  };

  return (
    <div className="container">
        <h1>Task List</h1>
        <Link to="/create" className="create-link">Create New Task</Link>
        <ul className="task-list">
            {tasks.map(task => (
                <li key={task.id} className="task-item">
                    <Link to={`/task/${task.id}`} className="task-title">{task.title}</Link>
                    <div className="task-buttons">
                        <button onClick={() => handleDelete(task.id)} className="delete-button">Delete</button>
                        
                    </div>
                </li>
            ))}
        </ul>
    </div>
);
}

export default TaskList;
